var islrsharing = true; var islrsocialcounter = true;
var LoginRadius={user_settings:{},user_settings:{apikey:"",app_domain:"",protocol:"",hybridsharing:"",sharecounttype:""},socialshare:{}},$SS=LoginRadius.socialshare;LoginRadius.socialcounter={};var $SC=LoginRadius.socialcounter;LoginRadius.util={};
(function(b){b.elementById=function(b){return document.getElementById(b)};b.elementsByClass=function(b,h){h=h?h:document.body;for(var d=[],f=RegExp("(^| )"+b+"( |$)"),e=h.getElementsByTagName("*"),c=0,m=e.length;c<m;c++)f.test(e[c].className)&&d.push(e[c]);return d};b.addEvent=function(b,h,d){var f=[];h instanceof Array?f=h:f.push(h);for(i=0;i<f.length;i++)f[i].attachEvent?f[i].attachEvent("on"+b,function(){d.call(f[i])}):f[i].addEventListener&&f[i].addEventListener(b,d,!1)};var g={};b.tmpl=function h(d,
f){var e=!/\W/.test(d)?g[d]=g[d]||h(b.elementById(d).innerHTML):new Function("obj","var p=[],print=function(){p.push.apply(p,arguments);};with(obj){p.push('"+d.replace(/[\r\t\n]/g," ").split("<%").join("\t").replace(/((^|%>)[^\t]*)'/g,"$1\r").replace(/\t=(.*?)%>/g,"',$1,'").split("\t").join("');").split("%>").join("p.push('").split("\r").join("\\'")+"');}return p.join('');");return f?e(f):e};b.openWindow=function(b){b=b||this.href;window.open(b,"lrpopupchildwindow","menubar=1,resizable=1,width=530,height=530");
return!1};b.addCss=function(b,d){for(var f in d)b.style[f]=d[f]};b.getPos=function(b){for(var d=0,f=0;null!=b;d+=b.offsetLeft,f+=b.offsetTop,b=b.offsetParent);return{x:d,y:f}};b.containsStringArray=function(b,d){for(var f=0;f<b.length;f++)if(-1!=b[f].indexOf(d))return!0;return!1};b.addExternalCss=function(b){if(b){var d=document.getElementsByTagName("head")[0],f=document.createElement("link");f.rel="stylesheet";f.type="text/css";f.media="all";f.href=b;d.appendChild(f)}};b.addEmbedCss=function(b){var d=
document.createElement("style");d.type="text/css";d.styleSheet?d.styleSheet.cssText=b:d.innerHTML=b;document.getElementsByTagName("head")[0].appendChild(d)};b.jsonpCall=function(b,d){if(b){var f="Loginradius"+Math.floor(1E18*Math.random()+1);window[f]=function(b){d(b);try{delete window[f]}catch(m){}document.body.removeChild(e)};var e=document.createElement("script");e.src=-1!=b.indexOf("?")?b+"&callback="+f:b+"?callback="+f;e.type="text/javascript";document.body.appendChild(e)}};b.getCornerCss=function(b,
d,f,e){var c={};d?c.right=d:c.left=b;e?c.bottom=e:c.top=f;return c}})(LoginRadius.util);
(function(b){function g(){if(!e&&(e=!0,c)){for(var b=0;b<c.length;b++)c[b].call(window,[]);c=[]}}function k(){if(!f){f=!0;document.addEventListener&&!d.opera&&document.addEventListener("DOMContentLoaded",g,!1);d.msie&&window==top&&function(){if(!e){try{document.documentElement.doScroll("left")}catch(b){setTimeout(arguments.callee,0);return}g()}}();d.opera&&document.addEventListener("DOMContentLoaded",function(){if(!e){for(var b=0;b<document.styleSheets.length;b++)if(document.styleSheets[b].disabled){setTimeout(arguments.callee,
0);return}g()}},!1);if(d.safari){var b;(function(){if(!e)if("loaded"!=document.readyState&&"complete"!=document.readyState)setTimeout(arguments.callee,0);else{if(void 0===b){for(var c=document.getElementsByTagName("link"),d=0;d<c.length;d++)"stylesheet"==c[d].getAttribute("rel")&&b++;c=document.getElementsByTagName("style");b+=c.length}document.styleSheets.length!=b?setTimeout(arguments.callee,0):g()}})()}var c=g,n=window.onload;window.onload="function"!=typeof window.onload?c:function(){n&&n();c()}}}
var h=navigator.userAgent.toLowerCase(),d={version:(h.match(/.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/)||[])[1],safari:/webkit/.test(h),opera:/opera/.test(h),msie:/msie/.test(h)&&!/opera/.test(h),mozilla:/mozilla/.test(h)&&!/(compatible|webkit)/.test(h)};b.browser=d;var f=!1,e=!1,c=[];b.ready=function(b){k();e?b.call(window,[]):c.push(function(){return b.call(window,[])})};k()})(LoginRadius.util);
(islrsharing||hybridsharing)&&function(b){function g(b,c){LoginRadius.util.addEvent("mouseover",b,function(){if("none"==$SS.evenMore.style.display||""==$SS.evenMore.style.display)$SS.url=c});var d=b.getElementsByTagName("div");if(d)for(var f=0;f<d.length;f++)LoginRadius.util.addEvent("mouseover",d[f],function(){if("none"==$SS.evenMore.style.display||""==$SS.evenMore.style.display)$SS.url=c})}$SS.providerClick=function(e){if(-1<e.indexOf("media")){var c="http://"+$SS.domain+"/share/"+b.user_settings.apikey+
"?ProviderID=pinterest&Url="+$SS.url+"&"+e+"&couttype="+b.user_settings.sharecounttype;$SS.hideimagepopup();b.util.openWindow(c)}else{c="http://"+$SS.domain+"/share/"+b.user_settings.apikey+"?ProviderID="+e+"&Url="+$SS.url+"&couttype="+b.user_settings.sharecounttype;$SS.hideEvenMore();$SS.hideMore();if("print"==e)window.print();else if("pinterest"==e){if(!$SS.imagesseleted){var d='<div class="lrshare_close_imageshare" onclick="$SS.hideimagepopup()"><img src="//'+$SS.domain+'/Content/css/pl_close_button.png" /></div><div class="lrshare_heading">Select the image you want to share on Pinterest !</div><div class="lrshare_contents"><div class="lrshare_imagelist"><ul><%for(var i=0;i<imgSrc.length;i++) {if(parseInt(imgSrc[i].width)>32 && parseInt(imgSrc[i].height) >32){%><li><span class="div_pinimages_spanouter loginradius_pinsharing_style"><span class="div_pinimages_spaninner" onclick=$SS.providerClick("media=+<%=imgSrc[i].src %>")><img title="<%=imgSrc[i].title %>" alt="<%=imgSrc[i].alt %>" src="<%=imgSrc[i].src %>" height="190px" width="190px" style="opacity: 1;"><div style="display: none;"></div></span><span class="atImgSpanSize"><%=imgSrc[i].width %> x <%=imgSrc[i].height %></span></span></li><%}}%></ul></div><div class="lrshare_poweredby" style="background-color:#fff;">Social Share by <a href="https://www.loginradius.com" target="_blank" style="text-decoration: none;"><span style="color: #00ccff; padding: 1px; text-shadow: none !important;">Login</span><span style="color: #000; text-shadow: none !important;">Radius</span></a></div></div>';
b.util.ready(function(){$SS.imagesfrompage=document.createElement("div");$SS.imgSrcs=document.getElementsByTagName("img");$SS.imagesfrompage.className="lrshare_imagepoup";$SS.imagesfrompage.style.display="none";$SS.imagesfrompage.innerHTML="";$SS.imagesfrompage.innerHTML=b.util.tmpl(d,{imgSrc:$SS.imgSrcs});document.body.appendChild($SS.imagesfrompage)});$SS.showimagepopup=function(){$SS.hideMore();$SS.imagesfrompage.style.display="block"};$SS.hideimagepopup=function(){$SS.imagesfrompage.style.display=
"none"};$SS.imgseach=function(b){var c=$SS.imagesfrompage.getElementsByTagName("li");for(i=0;i<c.length;i++)c[i].style.display=-1!=(c[i].innerText||c[i].textContent).toLowerCase().indexOf(b)?"block":"none"};$SS.imagesseleted=!0}$SS.showimagepopup()}else b.util.openWindow(c);$SS.callback&&$SS.callback(e)}};$SS.domain="share.loginradius.com";$SS.Interface={};$SS.Providers={};$SS.imgSrcs=[];$SS.imgSrc={};$SS.Providers.All="Facebook Pinterest BarraPunto BlinkList blogmarks connotea Current Delicious Digg Diigo DZone eKudos Fark FriendFeed Google GooglePlus Gwar HackerNews Haohao HealthRanker Hemidemi Hyves Kirtsy LaTafanera LinkArena LinkaGoGo LinkedIn Linkter Meneame MisterWong Mixx muti MyShare MySpace Netvibes NewsVine Netvouz NuJIJ Posterous PDF Print Ratimarks Reddit Scoopeo Segnalo Slashdot Sphinn StumbleUpon Technorati ThisNext Tumblr Twitter Upnews Vkontakte Wykop Xerpi Yigg Yahoo SheToldMe Diggita".split(" ");
$SS.Providers.Top=[];$SS.Providers.More="Facebook Pinterest Twitter Print Email Google Digg Reddit Vkontakte GooglePlus Tumblr LinkedIn MySpace Delicious Yahoo".split(" ");var k=document.createElement("link");k.href="//"+$SS.domain+"/Content/css/LoginRadiusShare.css";k.rel="stylesheet";k.type="text/css";k.media="all";document.getElementsByTagName("head")[0].appendChild(k);$SS.TotalShare=0;$SS.IsLabel=!1;$SS.imagesseleted=!1;$SS.url=encodeURIComponent(window.location.href);var h='<div class="lrshare_close" onclick="$SS.hideEvenMore()"><img src="//'+
$SS.domain+'/Content/css/pl_close_button.png" /></div><div class="lrshare_heading"><div style="float:left;width:70px !important;">SHARE</div><input type="text" class="lrshare_headingtitleinput" onkeyup="$SS.seach(this.value);" placeholder="Search your sharing network" /></div><div class="lrshare_contents"><div class="lrshare_iconlist"><ul><%for(var i=0;i<providers.length;i++) { %><li onclick=$SS.providerClick("<%=providers[i].toLowerCase()%>")><span class="lrshare_iconsprite16 lrshare_<%=providers[i].toLowerCase() %>"></span><%=providers[i] %> </li><%}%></ul></div><div class="lrshare_poweredby" style="background-color:#fff;">Social Share by <a href="https://www.loginradius.com" target="_blank" style="text-decoration: none;"><span style="color: #00ccff; padding: 1px; text-shadow: none !important;">Login</span><span style="color: #000; text-shadow: none !important;">Radius</span></a></div></div>';
b.util.ready(function(){$SS.evenMore=document.createElement("div");$SS.evenMore.className="lrshare_evenmorepoup";$SS.evenMore.innerHTML=b.util.tmpl(h,{providers:$SS.Providers.All});document.body.appendChild($SS.evenMore)});$SS.showEvenMore=function(){$SS.imagesseleted&&$SS.hideimagepopup();$SS.hideMore();$SS.evenMore.style.display="block"};$SS.hideEvenMore=function(){$SS.evenMore.style.display="none"};$SS.seach=function(b){var c=$SS.evenMore.getElementsByTagName("li");for(i=0;i<c.length;i++)c[i].style.display=
-1!=(c[i].innerText||c[i].textContent).toLowerCase().indexOf(b.toLowerCase())?"block":"none"};var d=function(){clearTimeout($SS.intervalmorehide);$SS.intervalmorehide=setTimeout($SS.hideMore,1E3)};b.util.ready(function(){$SS.More=document.createElement("div");$SS.More.className="lrshare_smallpopupevenmore";$SS.More.innerHTML=b.util.tmpl('<div class="lrshare_heading_smallevenmore">Bookmark & Share<div class="lrshare_close_smallevenmore" onclick="$SS.hideMore()"> <span class="closebuttonsprite close_span"></span></div></div><div class="lrshare_contents"><div class="lrshare_iconlist_smallevenmore"><ul><%for(var i=0;i<providers.length;i++) { %><li onclick=$SS.providerClick("<%=providers[i].toLowerCase()%>")><span class="lrshare_iconsprite16 lrshare_<%=providers[i].toLowerCase() %>"></span><%=providers[i] %> </li><%}%><li onclick=$SS.showEvenMore()><span class="lrshare_iconsprite16 lrshare_evenmore16"></span>More... </li></ul></div><div class="lrshare_poweredby">Social Share by <a href="https://www.loginradius.com" target="_blank" style="text-decoration: none;"><span style="color: #00ccff; padding: 1px; text-shadow: none !important;">Login</span><span style="color: #000; text-shadow: none !important;">Radius</span></a></div></div>',
{providers:$SS.Providers.More});document.body.appendChild($SS.More);b.util.addEvent("mouseout",$SS.More,function(){d()});b.util.addEvent("mouseover",$SS.More,function(){clearTimeout($SS.intervalmorehide)})});$SS.showMore=function(e){var c=b.util.getPos(e),f=window.screen.availHeight,g=e.offsetHeight+c.y+5,h=c.x,h=h+288>=window.screen.availWidth?h=c.x-210-10:h,g=g+288>=f?g=c.y-288+10:g;$SS.More.style.display="block";$SS.More.style.left=h+"px";$SS.More.style.top=g+"px";clearTimeout($SS.intervalmorehide);
b.util.addEvent("mouseout",e,function(){d()})};$SS.hideMore=function(){$SS.More.style.display="none"};$f=$SS.Interface.Simplefloat={};$f.left="";$f.right="";$f.top="";$f.bottom="";$f.size=0;b.user_settings.apikey=""==b.user_settings.apikey?"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx":b.user_settings.apikey;$f.show=function(e){b.util.jsonpCall("//"+$SS.domain+"/ApiData/"+b.user_settings.apikey+"?url="+$SS.url+"&url="+$SS.url+"&couttype="+b.user_settings.sharecounttype,function(b){$SS.IsLabel=b[0].iswhitelabel;
if("true"==b[0].iswhitelabel){b=LoginRadius.util.elementsByClass("lrshare_poweredby");for(var c=0;c<b.length;c++)b[c].style.display="none"}});$topproviders=$SS.Providers.Top;$f.size=$f.size||16;var c=$f.isHorizontal?"lrshare_floatleft":"";$f.template='<ul><% for(var i=0;i<providers.length;i++){ %><li><div onclick=$SS.providerClick("<%=providers[i].toLowerCase()%>") class="lrshare_iconsprite'+$f.size+" lrshare_<%=providers[i].toLowerCase() %> "+c+'" title="<%=providers[i]%>"></div></li><% } %>';$f.template+=
'<li><div onmouseover="$SS.showMore(this)" class="lrshare_iconsprite'+$f.size+" lrshare_evenmore"+$f.size+" "+c+'" title="more..."></div></li></ul>';c=e?b.util.elementsByClass(e)[0]:document.createElement("div");e||document.body.appendChild(c);c.className+=" lrshare_interfacebox";c.innerHTML=b.util.tmpl($f.template,{providers:$topproviders});e=(e=c.getAttribute("data-share-url"))||$SS.url;g(c,e);b.util.addCss(c,b.util.getCornerCss($f.left,$f.right,$f.top,$f.bottom))};var f=$SS.Interface.simpleimage=
{};f.show=function(e){b.util.jsonpCall("//"+$SS.domain+"/ApiData/"+(b.user_settings.apikey||"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")+"?url="+$SS.url+"&couttype="+b.user_settings.sharecounttype,function(b){$SS.IsLabel=b[0].iswhitelabel;if("true"==b[0].iswhitelabel){b=LoginRadius.util.elementsByClass("lrshare_poweredby");for(var c=0;c<b.length;c++)b[c].style.display="none"}});f.size=f.size||32;e=LoginRadius.util.elementsByClass(e);for(a=0;a<e.length;a++){e[a].className+=" lrshare_simpleshareimage"+f.size;
e[a].innerHTML="";var c=e[a].getAttribute("data-share-url"),c=c||$SS.url;g(e[a],c);b.util.addEvent("mouseover",e[a],function(){$SS.showMore(this)})}};$h=$SS.Interface.horizontal={};$h.size=0;b.user_settings.apikey=""==b.user_settings.apikey?"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx":b.user_settings.apikey;$h.show=function(e){$h=$h||16;$topproviders=$SS.Providers.Top;$h.template='<ul><% for(var i=0;i<providers.length;i++){ %><li><div onclick=$SS.providerClick("<%=providers[i].toLowerCase()%>") class="lrshare_iconsprite'+
$h.size+' lrshare_<%=providers[i].toLowerCase() %>" title="<%=providers[i]%>"></div></li><% } %>';$h.template+='<li><div onmouseover="$SS.showMore(this)" class="lrshare_iconsprite'+$h.size+" lrshare_evenmore"+$h.size+'"  title="more..."></div></li>';$h.template+='<li><div class="lrshare_iconsprite'+$h.size+" lrshare_sharingcounter"+$h.size+' lrshare-totalshare" title="total shares">'+$SS.TotalShare+"</div></li></ul>";var c=b.util.elementsByClass(e);e=b.util.tmpl($h.template,{providers:$topproviders});
for(x=0;x<c.length;x++){c[x].innerHTML=e;var d=c[x].getAttribute("data-share-url"),d=d||$SS.url;g(c[x],d);c[x].className+=" lrshare_interfacehorizontal";b.util.jsonpCall("//"+$SS.domain+"/ApiData/"+b.user_settings.apikey+"?url="+d+"&couttype="+b.user_settings.sharecounttype,function(e){return function(d){b.util.elementsByClass("lrshare-totalshare",c[e])[0].innerHTML=d[0].loginradiussharecount;$SS.IsLabel=d[0].iswhitelabel;if("true"==d[0].iswhitelabel){d=LoginRadius.util.elementsByClass("lrshare_poweredby");
for(var f=0;f<d.length;f++)d[f].style.display="none"}}}(x))}}}(LoginRadius);
islrsocialcounter&&function(b){var g;$SC.domain="share.loginradius.com";$SC.url=$SC.url||window.location.href;g={facebook:{id:"facebook-jssdk",src:"//connect.facebook.net/en_US/all.js#xfbml=1",buttons:{like:{html:'<div class="fb-like fb-like-#layout#" data-send="false" data-layout="#layout#"  data-show-faces="false" data-href="#url#"></div>',name:"Facebook Like"},recommend:{html:'<div class="fb-like" data-send="false" data-layout="#layout#"  data-show-faces="false" data-action="recommend"  data-href="#url#"></div>',name:"Facebook Recommend"},
send:{html:'<div class="fb-send fb_edge_widget_with_comment fb_iframe_widget"  data-href="#url#" ></div>',name:"Facebook Send"}},layouts:{horizontal:"button_count",verticle:"box_count"}},twitter:{id:"twitter-wjs",src:"//platform.twitter.com/widgets.js",buttons:{share:{html:'<a href="https://twitter.com/share" class="twitter-share-button"  data-url="#url#" data-count="#layout#">Tweet</a>',name:"Twitter Tweet"}},layouts:{horizontal:"horizontal",verticle:"vertical"}},google:{id:"google-plusone",src:"//apis.google.com/js/plusone.js",
buttons:{plusone:{html:'<div class="g-plusone"  style="width: 50px ! important; height: 25px ! important; vertical-align: bottom ! important;"  data-size="#layout#" data-href="#url#"></div>',name:"Google+ +1"},share:{html:'<div class="g-plus" data-action="share" data-annotation="#layout#" data-href="#url#"></div>',name:"Google+ Share"}},layouts:{horizontal:"hori",verticle:"tall",sharehorizontal:"bubble",shareverticle:"vertical-bubble"}},pinterest:{id:"pinterest-wjs",src:"//assets.pinterest.com/js/pinit.js",
buttons:{share:{html:'<a data-pin-config="#layout#" href="//pinterest.com/pin/create/button/" data-pin-do="buttonBookmark"  ><img src="//assets.pinterest.com/images/pidgets/pin_it_button.png" /></a>',name:"Pinterest Pin it"}},layouts:{horizontal:"beside",verticle:"above"}},linkedin:{id:"linkedin-wjs",src:"//platform.linkedin.com/in.js",buttons:{share:{html:'<script type="IN/Share" data-counter="#layout#" data-url="#url#">\x3c/script>',name:"LinkedIn Share"}},layouts:{horizontal:"right",verticle:"top"}},
stumbleupon:{id:"stumbleupon-wjs",src:"//platform.stumbleupon.com/1/widgets.js",buttons:{share:{html:'<su:badge layout="#layout#" location="#url#"></su:badge>',name:"StumbleUpon Badge"}},layouts:{horizontal:"1",verticle:"5"}},reddit:{buttons:{share:{html:'<iframe src="https://redditstatic.s3.amazonaws.com/button/button#layout# scrolling="no" frameborder="0" class="reddit_width"></iframe>',name:"Reddit"}},layouts:{horizontal:'1.html?width=120&url=#url#&newwindow=1" height="22" width="100" align="left"',
verticle:'2.html?width=51&url=#url#&newwindow=1" height="69" width="51"'}},hybridshare:{id:"hybridshare-wjs",buttons:{share:{html:'<div><div onmouseover="$SS.showMore(this)" class="lrshare_hybrid_share lrshare_hybrid_share_#layout#"  title="more..." style="float:left;"></div><div style="float:right;" class="lr_shares_count_#layout#"><iframe src="//'+$SC.domain+'/count/#apikey#?size=32&url=#url#&couttype=#scounttype#&datalayout=#layout#" frameborder="0" scrolling="no" allowtransparency="true" height="35" width="50" style="margin-top: 0px;"></iframe></div></div>',
name:"Hybridshare"}},layouts:{horizontal:"horizontal",verticle:"vertical"}}};$SC.Providers={};var k=$SC.Providers,h=[],d;for(d in g)if(g.hasOwnProperty(d))for(var f in g[d].buttons)g[d].buttons.hasOwnProperty(f)&&h.push(g[d].buttons[f].name);k.All=h;$SC.Providers.Selected=[];$SC.Interface={};$SC.url="";var e=$SC.Interface.simple={};e.left="";e.right="";e.top="";e.bottom="";e.countertype="";e.isHorizontal=e.isHorizontal||!1;$SC.url=$SC.url||window.location.href;e.show=function(c){var d="horizontal"==
e.countertype,f=[],h,j;for(j in g)if(g.hasOwnProperty(j))for(var k in g[j].buttons)if(g[j].buttons.hasOwnProperty(k)&&b.util.containsStringArray($SC.Providers.Selected,g[j].buttons[k].name)&&(h=g[j].buttons[k].name==g.google.buttons.share.name?d?g[j].layouts.sharehorizontal:g[j].layouts.shareverticle:d?g[j].layouts.horizontal:g[j].layouts.verticle,f.push(g[j].buttons[k].html.replace(/\#layout#/g,h).replace(/\#apikey#/g,LoginRadius.user_settings.apikey||"xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx").replace(/\#scounttype#/g,
"url")),g[j].src)){h=g[j].id;var p=g[j].src;if(p){var l=void 0,q=document.getElementsByTagName("script")[0];document.getElementById(h)||(l=document.createElement("script"),l.id=h,l.src=p,q.parentNode.insertBefore(l,q))}}"horizontal"==e.countertype?(LoginRadius.util.addEmbedCss(".IN-widget { float:none !important; height:auto;}  .reddit_width{vertical-align: bottom;}"),LoginRadius.util.addEmbedCss(".a.PIN_1364561637082_pin_it_button.PIN_1364561637082_pin_it_above{margin-top:38px !important;} .IN-widget { float:none !important;} .reddit_width{vertical-align: bottom;} .twitter-share-button {width: 80px !important;}")):
LoginRadius.util.addEmbedCss(" .reddit_width{vertical-align: bottom;} .IN-widget { float:none !important; } .lrshare_hybrid_share_vertical{margin-top:37px !important;} .lr_shares_count_vertical{margin-left:-58px !important;float:left !important;} .reddit_width{vertical-align: bottom;} .twitter-share-button {width: 80px !important;}");e.isHorizontal?(template='<table style="border:none !important;background:none !important;"><tbody style="border:none !important;background:none !important;"><tr style="border:none !important;background:none !important;"> <% for(var i=0;i<buttons.length;i++){ %> <td style="border:none !important;background:none !important;"><%= buttons[i] %></td><% } %></tr></tbody></table>',
d={}):(template='<table style="border:none !important;background:none !important;"><tbody style="border:none !important;background:none !important;"> <% for(var i=0;i<buttons.length;i++){ %><tr style="border:none !important;background:none !important;"><td style="border:none !important;background:none !important;"><%= buttons[i] %></td></tr><% } %></tbody></table>',d=b.util.getCornerCss(e.left,e.right,e.top,e.bottom),d.position="fixed");f=b.util.tmpl(template,{buttons:f});c=b.util.elementsByClass(c);
for(j=0;j<c.length;j++)k=c[j].getAttribute("data-counter-url")||$SC.url,c[j].innerHTML=f.replace(/\#url#/g,k),c[j].className=c[j].className+" lrcounter-"+(e.isHorizontal?"horizontal":"vertical")+"-"+e.countertype,LoginRadius.util.addCss(c[j],{"background-color":"transparent",border:"0px solid #DDDDDD","border-radius":"6px 6px 6px 6px",padding:"0px",clear:"both",display:"inline-block","text-align":"center","box-shadow":"0 0 0px #D1D1D1 inset","z-index":"9999"}),LoginRadius.util.addCss(c[j],d)};b.util.addEmbedCss(".lrcounter-vertical-horizontal tr td{border:none!important;background:none!important;color:#000!important;}.fb_iframe_widget iframe {position: relative !important;}.fb_iframe_widget span {display: inline-block !important; position: relative;text-align: justify;width:auto !important;}.lrcounter-vertical-horizontal table{border:none!important;background:none!important;color:#000!important;margin:0!important;padding:0!important;text-align:left !important;}.lrcounter-horizontal-vertical table{ background: none !important; border: medium none !important; color: #000000 !important; margin:0 !important;padding:0 !important; text-align:left !important;}.lrcounter-horizontal-vertical table tr,.lrcounter-horizontal-vertical table td {background: none repeat scroll 0 0 transparent !important;  border: medium none !important; color: #000000 !important;display: inline-table;  margin-left: 4px !important;  padding: 0 2px !important; text-align: left !important; vertical-align: bottom !important;}.lrcounter-horizontal-horizontal{background: none repeat scroll 0 0 transparent !important;  border: medium none !important; color: #000000 !important;display: inline-table;  margin: 0 !important;  padding: 0 2px !important; text-align: left !important; vertical-align: bottom !important;}.lrshare_hybrid_share_vertical{height: 27px !important;}.lrcounter-horizontal-horizontal td { border: medium none !important;display: inline-table;padding:0 !important;vertical-align: middle;}")}(LoginRadius);
// prepare rearrange provider list
function loginRadiusHorizontalRearrangeProviderList(elem){
	var ul = document.getElementById('horsortable');
	if(elem.checked){
		var listItem = document.createElement('li');
		listItem.setAttribute('id', 'lrhorizontal_'+elem.value);
		listItem.setAttribute('title', elem.value);
		listItem.setAttribute('class', 'lrshare_iconsprite32 lrshare_'+elem.value);
		// append hidden field
		var provider = document.createElement('input');
		provider.setAttribute('type', 'hidden');
		provider.setAttribute('name', 'horizontal_rearrange[]');
		provider.setAttribute('value', elem.value);
		listItem.appendChild(provider);
		ul.appendChild(listItem);
	}
	else{
		if(document.getElementById('lrhorizontal_'+elem.value)){
			ul.removeChild(document.getElementById('lrhorizontal_'+elem.value));
		 }
	}
}
// prepare rearrange provider list
function loginRadiusVerticalRearrangeProviderList(elem){
	var ul = document.getElementById('versortable');
	if(elem.checked){
		var listItem = document.createElement('li');
		listItem.setAttribute('id', 'lrvertical_'+elem.value);
		listItem.setAttribute('title', elem.value);
		listItem.setAttribute('class', 'lrshare_iconsprite32 lrshare_'+elem.value);
		// append hidden field
		var provider = document.createElement('input');
		provider.setAttribute('type', 'hidden');
		provider.setAttribute('name', 'vertical_rearrange[]');
		provider.setAttribute('value', elem.value);
		listItem.appendChild(provider);
		ul.appendChild(listItem);
	}else{
		if(document.getElementById('lrvertical_'+elem.value)){
			ul.removeChild(document.getElementById('lrvertical_'+elem.value));
		 }
	}
}
// check provider more then 9 select
function loginRadiusVerticalSharingLimit(elem){
	var provider = $("#sharevprovider").find(":checkbox");
	var checkCount = 0;
	for(var i = 0; i < provider.length; i++){
		if(provider[i].checked){
			// count checked providers
			checkCount++;
			if(checkCount >= 10){
				elem.checked = false;
				$("#loginRadiusVerticalSharingLimit").show('slow');
				setTimeout(function() {
					$("#loginRadiusVerticalSharingLimit").hide('slow');
				}, 5000);
				//document.getElementById('loginRadiusSharingLimit').style.display = 'block';
				return;
			}
		}
	}
}
function loginRadiusHorizontalSharingLimit(elem){
	var provider = $("#sharehprovider").find(":checkbox");
	var checkCount = 0;
	for(var i = 0; i < provider.length; i++){
		if(provider[i].checked){
			// count checked providers
			checkCount++;
			if(checkCount >= 10){
				elem.checked = false;
				$("#loginRadiusHorizontalSharingLimit").show('slow');
				setTimeout(function() {
					$("#loginRadiusHorizontalSharingLimit").hide('slow');
				}, 5000);
				//document.getElementById('loginRadiusSharingLimit').style.display = 'block';
				return;
			}
		}
	}
}
//select counter in checkbox and rearrange
function createhorsharprovider() {
  document.getElementById('lrhorizontalshareprovider').style.display="block";
  document.getElementById('lrhorizontalsharerearange').style.display="block";
  document.getElementById('lrhorizontalcounterprovider').style.display="none";
  document.getElementById('horizontalPageSelect').style.background="#EBEBEB";
  }
//single image in provider
function singleimgsharprovider(){
	document.getElementById('lrhorizontalshareprovider').style.display="none";
	document.getElementById('lrhorizontalsharerearange').style.display="none";
	document.getElementById('lrhorizontalcounterprovider').style.display="none";
	document.getElementById('horizontalPageSelect').style.background="#EBEBEB";
}
//select counter in checkbox
function createhorcounprovider() {
  document.getElementById('lrhorizontalcounterprovider').style.display="block";
  document.getElementById('lrhorizontalsharerearange').style.display="none";
  document.getElementById('lrhorizontalshareprovider').style.display="none";
  document.getElementById('horizontalPageSelect').style.background="#FFFFFF";
  }
function createversharprovider() {
  document.getElementById('lrverticalshareprovider').style.display="block";
  document.getElementById('lrverticalsharerearange').style.display="block";
  document.getElementById('lrverticalcounterprovider').style.display="none";
  document.getElementById('verticalPageSelect').style.background="#EBEBEB";
  }
//select counter in checkbox
function createvercounprovider() {
  document.getElementById('lrverticalcounterprovider').style.display="block";
  document.getElementById('lrverticalsharerearange').style.display="none";
  document.getElementById('lrverticalshareprovider').style.display="none";
  document.getElementById('verticalPageSelect').style.background="#FFFFFF";
  }
function Makevertivisible() {
  document.getElementById('sharevertical').style.display="block";
  document.getElementById('sharehorizontal').style.display="none";
  document.getElementById('arrow').style.cssText = "position:absolute; border-bottom:8px solid #ffffff; border-right:8px solid transparent; border-left:8px solid transparent; margin:-18px 0 0 70px;";
  document.getElementById('mymodal2').style.color = "#00CCFF";
  document.getElementById('mymodal1').style.color = "#000000";
}
function Makehorivisible() {
  document.getElementById('sharehorizontal').style.display="block";
  document.getElementById('sharevertical').style.display="none";
  document.getElementById('arrow').style.cssText = "position:absolute; border-bottom:8px solid #ffffff; border-right:8px solid transparent; border-left:8px solid transparent; margin:-18px 0 0 2px;";
  document.getElementById('mymodal1').style.color = "#00CCFF";
  document.getElementById('mymodal2').style.color = "#000000";
}
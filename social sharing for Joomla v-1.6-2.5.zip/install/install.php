<?php
defined ('_JEXEC') or die ('Direct Access to this location is not allowed.');
jimport('joomla.filesystem.folder');
jimport('joomla.installer.installer');
$rows = '';
$db = JFactory::getDBO ();
$manifest = $this->manifest;
$src = $this->parent->getPath('source');
$status = new JObject();
$status->modules = array();
$status->plugins = array();
// Load sociallogin language file
$lang = JFactory::getLanguage();
$lang->load('com_socialsharing', JPATH_SITE);

// Install plugin.
  if ($manifest instanceof JXMLElement AND property_exists ($manifest, 'plugins')) {
    if ($manifest->plugins instanceof JXMLElement) {
      foreach ($manifest->plugins->children () AS $plugin) {
        $plg_data = array ();
        foreach ($plugin->attributes () as $key => $value) {
          $plg_data [$key] = strval ($value);
        }
        $this->parent->setPath ('extension_root', JPATH_ROOT . DS . 'plugins' . DS . $plg_data ['group'] . DS . $plg_data ['plugin']);
        $created = false;
        if (!file_exists ($this->parent->getPath ('extension_root'))) {
          if (!$created = JFolder::create ($this->parent->getPath ('extension_root'))) {
            $this->parent->abort (JText::_ ('Plugin') . ' ' . JText::_ ('Install') . ': ' . JText::_ ('COM_SOCIALLOGIN_INSTALLATION_MODULE_PLG_ERROR') . ': "' . $this->parent->getPath ('extension_root') . '"');
            return false;
          }
        }
        if ($created) {
          $this->parent->pushStep (array (
					'type' => 'folder',
					'path' => $this->parent->getPath ('extension_root')
				));
        }
        if ($this->parent->parseFiles ($plugin->files, -1) === false) {
          $this->parent->abort ();
          return false;
        }
        $plg_data ['manifest_cache'] = json_encode (JApplicationHelper::parseXMLInstallFile (JPATH_ROOT . DS . 'plugins' . DS . $plg_data ['group'] . DS . $plg_data ['plugin'] . DS . $plg_data ['plugin'] . '.xml'));
        $query = 'SELECT `extension_id` FROM `#__extensions` WHERE folder = ' . $db->Quote ($plg_data ['group']) . ' AND type=\'plugin\' AND element = ' . $db->Quote ($plg_data ['plugin']);
        $db->setQuery ($query);
        if (!$db->Query ()) {
          $this->parent->abort (JText::_ ('Plugin') . ' ' . JText::_ ('Install') . ': ' . $db->stderr (true));
          return false;
        }
        $plugin_id = $db->loadResult ();
        if (empty ($plugin_id)) {
          $plugin_data = array ();
          $plugin_data ['name'] = $plg_data ['title'];
          $plugin_data ['type'] = 'plugin';
          $plugin_data ['element'] = $plg_data ['plugin'];
          $plugin_data ['folder'] = $plg_data ['group'];
          $plugin_data ['client_id'] = 0;
          $plugin_data ['enabled'] = 1;
          $plugin_data ['access'] = 1;
          $plugin_data ['protected'] = 0;
          $plugin_data ['manifest_cache'] = $plg_data ['manifest_cache'];
          $plugin_data ['params'] = '{}';
          $table = JTable::getInstance ('extension');
          if (!$table->bind ($plugin_data)) {
            $this->parent->abort (JText::_ ('Plugin') . ' ' . JText::_ ('Install') . ': ' . JText::_ ('table->bind throws error'));
            return false;
          }
          if (!$table->check ($plugin_data)) {
           $this->parent->abort (JText::_ ('Plugin') . ' ' . JText::_ ('Install') . ': ' . JText::_ ('table->check throws error'));
			return false;
		  }
          if (!$table->store ($plugin_data)) {
            $this->parent->abort (JText::_ ('Plugin') . ' ' . JText::_ ('Install') . ': ' . JText::_ ('table->store throws error'));
            return false;
          }
          $this->parent->pushStep (array (
					'type' => 'extension',
					'extension_id' => $table->extension_id
				));
        }
         // Plugin Installed
			$status->plugins[] = array('name'=>$plg_data ['plugin'],'group'=>$plg_data ['group']);      
	  }
    }
  }

// Installation completed.
if (count($status->plugins)) {?>
  <h2>Social Sharing Installation</h2>
<table class="adminlist">
	<thead>
		<tr>
			<th class="title" colspan="2"><?php echo JText::_('Extension'); ?></th>
			<th><?php echo JText::_('Status'); ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td colspan="3"></td>
		</tr>
	</tfoot>
	<tbody>
	    <tr>
			<th><?php echo JText::_('Component'); ?></th>
			<th></th>
			<th></th>
		</tr>
		<tr class="row0">
			<td class="key" colspan="2"><?php echo 'Social Sharing '.JText::_('Component'); ?></td>
			<td style="color:#6c9c31;"><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>

<?php if (count($status->plugins)) : ?>
		<tr>
			<th><?php echo JText::_('Plugin'); ?></th>
			<th><?php echo JText::_('Group'); ?></th>
			<th></th>
		</tr>
	<?php foreach ($status->plugins as $plugin) : ?>
		<tr class="row<?php echo (++ $rows % 2); ?>">
			<td class="key"><?php echo ucfirst($plugin['name']); ?></td>
			<td class="key"><?php echo ucfirst($plugin['group']); ?></td>
			<td style="color:#6c9c31;"><strong><?php echo JText::_('Installed'); ?></strong></td>
		</tr>
	<?php endforeach;
endif; ?>
	</tbody>
</table>

	<h2><?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_STATUS'); ?></h2>
	<p class="nowarning">
		<?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_THANK'); ?> <strong>Social Sharing</strong>!
		<?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_CONFIG'); ?> <a href="index.php?option=com_socialsharing">Social Sharing <?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_COM'); ?></a>
		<?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_FREE'); ?> <a href="https://www.loginradius.com/loginradius/contact" target="_blank"><?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_CONTACT'); ?></a> <?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_ASSIST'); ?>
		<strong><?php echo JText::_ ('COM_SOCIALLOGIN_INSTALLATION_THANKYOU'); ?></strong>
		</p>
<?php 
 }
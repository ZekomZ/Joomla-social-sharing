<?php

defined ('_JEXEC') or die ('Direct Access to this location is not allowed.');

